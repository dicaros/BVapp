import React from 'react'
import ReactDOM from 'react-dom'
import App from './Api'
import './index.css'

ReactDOM.render(<App />, document.getElementById('root'))