import React, { Component } from 'react';

 var data = "http://localhost:8080/api/employees";


 class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      items: [],
      links: [],
      employees: null,
      page: 0,
      totalPages: 0
    };
  }; 


    loadFromServer(currentPage) {
                  fetch(data+"?page="+currentPage)
                 .then(res => res.json())
                 .then(res => {
                     this.setState({
                        isLoaded: true,
                        items: res,
                        employees: res._embedded.employees,
                        links: res._links,
                        totalPages: res.page.totalPages
                     }); 
                    })
                  .catch(error => 
                       this.setState({
                         isLoaded: true,
                         error: error
                    })
                  );
}


  componentDidMount() {  
                this.loadFromServer(this.state.page);
  };

  nextPage(currentPage) {
                if(currentPage+1<this.state.totalPages)
                {   this.setState ({
                          page: currentPage+1
                                        });
                      currentPage = currentPage+1;
                        this.loadFromServer(currentPage)
                      }
  };

  prevPage(currentPage) {

                if(currentPage>0)
                {
                this.setState ({
                    page: currentPage-1
                });
                currentPage = currentPage-1;
                this.loadFromServer(currentPage)
                }
  };

  render() {
        

        const TableHeader = () => {
                        return (
                                      <thead>
                                          <tr>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Desription</th>
                                          </tr>
                                      </thead>
                                )
                              };

        const { error, isLoaded, items, employees, links, page, totalPages } = this.state;
        
        const TableBody = () => {
                      if (error) {
                            return <div>Error: {error.message}</div>} 
                            else if (!isLoaded) {return <div>Loading...</div>}
                            else {
                                  console.log(this.state.items);
                                return (
                                      employees.map ((row, index) => 
                                        {
                                            return (
                                              <tbody>
                                                <tr key={index}>
                                                      <td>{row.firstName}</td>
                                                      <td>{row.lastName}</td>
                                                      <td>{row.description}</td>
                                                </tr>
                                              </tbody>
                                        )}
                                        )
                                      );
                                  }
                            }

        const TableFooter = () => {
                      if (error) {
                            return <div>Error: {error.message}</div>} 
                            else if (!isLoaded) {return <div>Loading...</div>}
                            else {
                                  console.log(this.state.items);
                                  return (
                                      <tfoot>
                                                <tr key="footer">
                                                      <button onClick={() => this.prevPage(this.state.page)}>Prev</button>
                                                      <button onClick={() => this.nextPage(this.state.page)}>Next</button>
                                                      <button onClick={() => alert(this.state.totalPages)}>Next</button>
                                                </tr>
                                      </tfoot>
                                      );
                                  }
                            }

        return (
            <table>
              <TableHeader />
              <TableBody />
              <TableFooter />
            </table>
           );
        }
}

export default App